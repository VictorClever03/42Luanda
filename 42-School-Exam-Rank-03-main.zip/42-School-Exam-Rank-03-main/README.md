# Norminette

There's no norminette in this exam 💻

# 1 Exam Question

Either Get_Next_Line or Ft_Printf:

- [Get_Next_Line](https://github.com/pasqualerossi/42-School-Exam-Rank-03/tree/main/get_next_line)

- [Ft_Printf](https://github.com/pasqualerossi/42-School-Exam-Rank-03/tree/main/ft_printf) 

if you can make the code shorter, but readable, let me know!

# Exam Practice Tool

Practice the exam just like you would in the real exam with this tool - https://github.com/JCluzet/42_EXAM
