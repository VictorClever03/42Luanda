# Exam Details
3 Questions in C++

:one: Warlock - [Subject Text](https://github.com/mvomiero/42-School-Exam-Rank-05/blob/fix-ex02/cpp_module_00/subject.txt)

:two: Question 1 and Aspell, Atarget, Dummy and Fwoosh - [Subject Text](https://github.com/mvomiero/42-School-Exam-Rank-05/blob/fix-ex02/cpp_module_01/subject.txt)

:three: Question 1, Question 2 and BrickWall, Fireball, Polymorph, SpellBook and TargetGenerator - [Subject Text](https://github.com/mvomiero/42-School-Exam-Rank-05/blob/fix-ex02/cpp_module_02/subject.txt)

<br>

### Total Excepted Files

> 16 .cpp (c++ files) and 16 .hpp (header files) = 32 files total.

<br>

# Exam Practice Tool

Practice the exam just like you would in the real exam - https://github.com/JCluzet/42_EXAM
